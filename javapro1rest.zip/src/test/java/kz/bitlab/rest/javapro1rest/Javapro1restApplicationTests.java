package kz.bitlab.rest.javapro1rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Javapro1restApplicationTests {

	@Test
	void contextLoads() {
	}

}
